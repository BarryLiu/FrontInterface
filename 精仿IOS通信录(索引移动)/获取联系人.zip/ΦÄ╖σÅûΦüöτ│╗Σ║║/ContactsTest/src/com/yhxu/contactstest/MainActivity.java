package com.yhxu.contactstest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.yhxu.contact.ContactsActivity;

public class MainActivity extends Activity {
	private TextView contact_show;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		contact_show = (TextView) findViewById(R.id.contact_show);
		Button contact_btn = (Button) findViewById(R.id.contact_btn);
		contact_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, ContactsActivity.class);
				startActivityForResult(intent, 2);
			}
		});
	}
	
	/**
	 * ͨѶ¼���ά��ɨ��ص��¼�
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		 if (requestCode == 2 && resultCode == 20) {// ͨѶ¼������
			 contact_show.setText("������"+data.getExtras().get("Name")+"\n���룺"+data.getExtras().get("phoneNumber"));
		 }
	}
}
